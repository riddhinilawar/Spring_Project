package com.practice.spring.learnspringframework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.practice.spring.learnspringframework.enterprise.MyWebController;

//import com.practice.spring.learnspringframework.enterprise.MyWebController;
import com.practice.spring.learnspringframework.game.*;

@SpringBootApplication
//@ComponentScan("com.in28minutes.spring.learnspringframework")
//@ComponentScan({"com.package1", "com.package2"})
public class LearnSpringFrameworkApplication {

	public static void main(String[] args) {
		

		//MarioGame game = new MarioGame();
		//SuperContraGame game = new SuperContraGame();

		//GamingConsole game = new MarioGame(); //1
		//GameRunner runner = new GameRunner(game); //2

		ConfigurableApplicationContext context 
					= SpringApplication.run(LearnSpringFrameworkApplication.class, args);

		GameRunner runner = context.getBean(GameRunner.class);
		runner.run();
		
		MyWebController controller = context.getBean(MyWebController.class);
		System.out.println(controller.returnValueFromBusinessService());
		
		
	}

}