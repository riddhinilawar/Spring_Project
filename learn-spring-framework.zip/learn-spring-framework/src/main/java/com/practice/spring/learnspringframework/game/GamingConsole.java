package com.practice.spring.learnspringframework.game;

public interface GamingConsole {
	void up();
	void down();
	void left();
	void right();
}